<!doctype html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta charset="utf-8">
<meta http-equiv="x-ua-compatible" content="ie=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimum-scale=1.0, maximum-scale=1.0" />
<link href='http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,600,700,800,300' rel='stylesheet' type='text/css'>

<meta name="owner" content="contact@jaja-photographie.com" />
<meta name="copyright" content="© jaja-design.com" />
<meta name="author" content="www.jaja-photographie.com" />
    
<title>LPATC - Flight Singles</title>

<link rel="stylesheet" href="build/css/styles.css" media="all">
<link rel="stylesheet" href="node_modules/bootstrap/dist/css/bootstrap.min.css" media="all">

</head>

<body>